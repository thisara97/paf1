package org.restapi.crud.crud.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import org.restapi.crud.crud.model.crudmodel;




public class crudservice {

	Connection con;	
	
	
	
	public crudservice() {
		
		try {
			String url =String.format("jdbc:mysql://localhost:3306/Databe_Name");
			String uname ="root";
			String pwd = "root";
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,uname,pwd);
			
			
			
			
		}catch(Exception e) {
			System.out.println(e +"data insert unsuccess.");
			
		}
	}
	
	
	public crudmodel insertUser(crudmodel user) {
		String insert = "insert into table_Name(AccountNumber,Category,Complaint,Name,Address,PhoneNumber,Email,AnythingMoreToTell) values(?,?,?,?,?,?,?,?) ";
		
		try {
			PreparedStatement ps = con.prepareStatement(insert);
			ps.setLong(1, user.getAccountNumber());
			ps.setString(2, user.getCategory());
			ps.setString(3, user.getComplaint());
			ps.setString(4, user.getName());
			ps.setString(5, user.getAddress());
			ps.setLong(6,user.getPhoneNumber());
			ps.setString(7, user.getEmail());
			ps.setString(8, user.getAnythingMoreToTell());
			
			
			

			
			
			
			
			
			ps.execute();
		}catch(Exception e) {
			System.out.println(e +"data insert unsuccess.");
		}
		
		
		return user;
		
	
}
}