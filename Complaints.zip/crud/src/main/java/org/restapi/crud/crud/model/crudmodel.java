package org.restapi.crud.crud.model;

public class crudmodel {
	
	private int AccountNumber;
	private String Category;
	private String Complaint;
	private String Name;
	private String Address;
	private int PhoneNumber;
	private String Email;
	private String AnythingMoreToTell;
	
	public crudmodel() {
		
	
	}
	
	
	public crudmodel(int accountNumber, String category, String complaint, String name, String address, int phoneNumber,
			String email, String anythingMoreToTell) {
		super();
		this.AccountNumber = accountNumber;
		this.Category = category;
		this.Complaint = complaint;
		this.Name = name;
		this.Address = address;
		this.PhoneNumber = phoneNumber;
		this.Email = email;
		this.AnythingMoreToTell = anythingMoreToTell;
	}


	public int getAccountNumber() {
		return AccountNumber;
	}


	public void setAccountNumber(int accountNumber) {
		AccountNumber = accountNumber;
	}


	public String getCategory() {
		return Category;
	}


	public void setCategory(String category) {
		Category = category;
	}


	public String getComplaint() {
		return Complaint;
	}


	public void setComplaint(String complaint) {
		Complaint = complaint;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public int getPhoneNumber() {
		return PhoneNumber;
	}


	public void setPhoneNumber(int phoneNumber) {
		PhoneNumber = phoneNumber;
	}


	public String getEmail() {
		return Email;
	}


	public void setEmail(String email) {
		Email = email;
	}


	public String getAnythingMoreToTell() {
		return AnythingMoreToTell;
	}


	public void setAnythingMoreToTell(String anythingMoreToTell) {
		AnythingMoreToTell = anythingMoreToTell;
	}
	
	
	 
	
	
	
	
	
	
	

}
